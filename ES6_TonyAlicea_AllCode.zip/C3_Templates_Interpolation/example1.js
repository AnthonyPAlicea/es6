const firstname = 'Tony';
const lastname = 'Alicea';
const fullname = `Hello, ${firstname} ${lastname}`;

console.log(fullname);