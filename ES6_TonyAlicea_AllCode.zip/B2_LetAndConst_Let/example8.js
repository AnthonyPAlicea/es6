let person = {firstnames: ['Tony', 'Anthony']};

for (let person of person.firstnames) {
    console.log(person);
}