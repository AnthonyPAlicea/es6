let person = {firstnames: ['Tony', 'Anthony']};

for (person of person.firstnames) {
    console.log(person);
}