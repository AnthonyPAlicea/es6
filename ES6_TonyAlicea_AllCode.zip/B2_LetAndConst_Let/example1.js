let firstname = 'Tony';
console.log(firstname); // not on the global object