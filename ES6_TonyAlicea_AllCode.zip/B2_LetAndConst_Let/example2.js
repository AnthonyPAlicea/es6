// not an error with 'var'
let firstname = 'Tony';
let firstname = 'Anthony';
console.log(firstname);