let firstname = 'Tony';

{
    console.log(firstname); // found, by looking at the outer environment record
}