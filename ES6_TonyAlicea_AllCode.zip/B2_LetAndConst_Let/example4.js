let firstname = 'Tony';

{
    let firstname = 'Anthony';
    console.log(firstname);
}

console.log(firstname);