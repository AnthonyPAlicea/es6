console.log(a); // error (but still hoisted)
let a;