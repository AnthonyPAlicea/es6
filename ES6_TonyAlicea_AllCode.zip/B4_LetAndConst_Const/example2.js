const firstname = 'Tony';
firstname = 'Anthony'; // error
console.log(firstname);