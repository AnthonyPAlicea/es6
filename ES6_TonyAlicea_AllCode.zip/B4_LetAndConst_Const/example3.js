const me = { firstname: 'Tony', lastname: 'Alicea' };
me.firstname = 'Anthony'; // only binding is immutable, not value
console.log(me);