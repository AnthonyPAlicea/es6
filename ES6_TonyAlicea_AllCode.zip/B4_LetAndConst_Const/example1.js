const firstname = 'Tony';

{
    const firstname = 'Anthony';
    console.log(firstname);
}

console.log(firstname);