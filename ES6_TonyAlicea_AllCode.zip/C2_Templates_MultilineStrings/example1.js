const firstname = 'Tony';
const lastname = 'Alicea';
const fullname = 'Tony\nAlicea';
const fullname2 = `Tony
Alicea`;

console.log(fullname == fullname2);